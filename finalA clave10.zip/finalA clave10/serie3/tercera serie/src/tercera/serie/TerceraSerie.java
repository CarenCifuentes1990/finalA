/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tercera.serie;
import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class TerceraSerie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String edad = "";
        String nombre = "";
        
        System.out.println("ingrese su edad");
        Scanner D1 = new Scanner(System.in);
        edad = D1.nextInt();
        
        
        System.out.println("ingrese su nombre");
        Scanner D3 = new Scanner(System.in);
        nombre = D3.nextInt();
    
    }
    
    
}
