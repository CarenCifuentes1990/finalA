/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caren;
import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class Caren {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       String nombre ="";
        int edad; 
      
        
        System.out.println("ingrese su nombre");
        Scanner D1 = new Scanner(System.in);
        edad = D1.nextInt();
        
        if 
                {

    }
                
        
        
        
        
                
        
    
                
                
                
        
    }
    
}
