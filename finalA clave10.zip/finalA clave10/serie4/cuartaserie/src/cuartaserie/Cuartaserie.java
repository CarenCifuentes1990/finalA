/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuartaserie;
import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class Cuartaserie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a;
int b;

 System.out.println("ingrese cantidad");
 Scanner D1 = new Scanner(System.in);
 a = D1.nextInt();

 for (b=0; b<=10; b=b+1)
 System.out.println(a); { 
}
}
}
    
    

